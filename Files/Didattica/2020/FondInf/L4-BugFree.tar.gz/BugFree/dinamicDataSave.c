//
// Created by alfy on 05/12/20.
//
#include <sysexits.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define fflush(stdin) while ((getchar()) != '\n')

#define len 64

struct dataNode{
    int count;
    char dataWrite[len];
};

int counter = 0;
struct dataNode* makeNode(char *text){
    struct dataNode* node;
    node = malloc(sizeof(struct dataNode));
    memset(node,0,sizeof(struct dataNode));
    node->count = counter;
    counter++;
    strcpy(node->dataWrite,text);
    return node;
}

void printNode(struct dataNode* node){
    printf("(%d) %s\n",node->count,node->dataWrite);

}

int main (int argc, char* argv[]){
    struct dataNode *storeNode[100];
    int i = 0;
    char input[len];
    while (strcmp(input,"q")!=0){
        printf("Inserire una frase da salvare:\n>>\t");
        scanf("%[^\n]",input);
        fflush(stdin);              // Senza si lascerebbe lo stdin sporco con \n ancora presente
        storeNode[i] = makeNode(input);
        i++;
    }

    i--;    // Poichè ho già fatto un ++ per il nuovo

    for(;i>=0;i--){     // è importante prendere anche l'ultimo elemento andando all'indietro
        printNode(storeNode[i]);
    }

    printf("Liberiamo la memoria:\n");
    for (int j = 0; j < counter; ++j) {  //Minore stretto, altrimenti si supera l'ultimo elemento
        free(storeNode[j]);
    }
    printf("Free- terminata\n");

    return EX_OK;
}