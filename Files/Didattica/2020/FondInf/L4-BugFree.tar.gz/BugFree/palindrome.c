/*
 * Il Programma prende una stringa da argv e mediante una
 * funzione ricorsiva ritorna all'utente se la stringa è
 * palindroma o meno
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int isPalindrome(char *s, int len) {
	int res;
	
	if (len<2) {
		return 1;
	}
	// Le funioni ricorsive funzionano bene solo se i parametri sono opportuni
	// Era necessario ridurre la len di -1 per togliere anche l'ultimo carattere.
	res = isPalindrome(&s[1], len-2) && (s[0] == s[len-1]);
	return res;	
}


int main(int argc, char **argv) {
	char *s;
	int len;
	
	if (argc != 2) {
		printf("Error! Usage: <string>\n");
		return EXIT_FAILURE;		
	}
	
	len = strlen(argv[1]);
	if ((s = malloc(sizeof(char)*len)) == NULL) {
		printf("Malloc error\n");
		return EXIT_FAILURE;		
	} 
	strcpy(s, argv[1]);
	
	if (isPalindrome(s, len)) {
		printf("La stringa %s è palindroma\n", s);
	}
	else {
		printf("La stringa %s non è palindroma\n", s);
	}
	
	return EXIT_SUCCESS;		
}
