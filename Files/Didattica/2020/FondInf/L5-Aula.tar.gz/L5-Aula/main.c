//
// Created by alfy on 21/12/20.
//
#include "treeLib.h"
#include "queueLib.h"

void bfsPrint(node *n){

    queue *q = initQueue();
    push(q,n);
    while ((n=pop(q))!=NULL){
        printNode(n);
        if(n->L)
            push(q,n->L);
        if(n->R)
            push(q,n->R);
    }
    deleteQueue(q);
}

void dfsPrint(node *n){
    // op per ogni nodo
    printNode(n);

    // test end recursion
    if(isLeaf(n))
        return;

    // recursion zone
    if(n->L)            //test fine ricorsione
        dfsPrint(n->L); // zona ricorsione

    if(n->R)
        dfsPrint(n->R);
}

int main(int argc, char *argv[]){

    node root={
            .k=0,
            .D=NULL,
            .R=NULL,
            .L=NULL
    };

    addSon(LEFT,&root,1);
    addSon(RIGHT,&root,2);
    node *nodeL = root.L;
    addSon(LEFT,nodeL,3);
    addSon(RIGHT,nodeL,4);
    addSon(LEFT,root.R,5);
    addSon(RIGHT,root.R,6);
    addSon(LEFT,root.R->R,7);
    addSon(RIGHT,root.R->R,8);

    printf("DFS print\n");
    dfsPrint(&root);
    printf("\n");

    printf("BFS print\n");
    bfsPrint(&root);
    return 0;
}