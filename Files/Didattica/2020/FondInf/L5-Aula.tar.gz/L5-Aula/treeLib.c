//
// Created by alfy on 21/12/20.
//

#include "treeLib.h"

node *makeNode(int k){
    node *temp = (node *) malloc(sizeof(node));
    memset(temp,0,sizeof(node));
    temp->k=k;
    return temp;
}

// errno = EADDRINUSE mean pointer already in use
int addSon(int LorR, node *current, int k){
    if(!current){
        printf("[treeLib.c::addSon] current is NULL\n");
        exit(EX_NOINPUT);
    }
    switch (LorR) {
        case LEFT:
            if(!current->L){
                current->L = makeNode(k);
                current->L->D = current;
            } else{
                errno = EADDRINUSE;
                return -1;
            }
            break;
        case RIGHT:
            if(!current->R){
                current->R = makeNode(k);
                current->R->D = current;
            } else{
                errno = EADDRINUSE;
                return -1;
            }
            break;
        default:
            printf("[treeLib.c::addSon] LorR not valid\n");
            exit(EX_NOINPUT);
    }
    return 0;
}

// errno = EADDRNOTAVAIL mean the node is leaf
int deleteSon(int LorR, node *current){
    if(!current){
        printf("[treeLib.c::deleteSon] current is NULL\n");
        exit(EX_NOINPUT);
    }

    int kRet;
    switch (LorR) {
        case LEFT:
            if(current->L){
                kRet = current->L->k;
                free(current->L);
                current->L=NULL;
            } else{
                errno = EADDRNOTAVAIL;
                return -1;
            }
            break;
        case RIGHT:
            if(current->R){
                kRet = current->R->k;
                free(current->R);
                current->R=NULL;
            } else{
                errno = EADDRNOTAVAIL;
                return -1;
            }
            break;
        default:
            printf("[treeLib.c::deleteSon] LorR not valid\n");
            exit(EX_NOINPUT);
    }
    return kRet;
}

int isLeaf(node *n){
    return ((!n->L) && (!n->R));
}
int isRoot(node *n){
    return !n->D;
}

void printNode(node *n){
    printf("Node->k = %d\tisLeaf:%d\tisRoot:%d\n",n->k,isLeaf(n),isRoot(n));
}
