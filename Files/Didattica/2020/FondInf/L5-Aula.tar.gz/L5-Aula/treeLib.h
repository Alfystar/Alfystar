//
// Created by alfy on 21/12/20.
//

#ifndef DATASTRUCT_TREELIB_H
#define DATASTRUCT_TREELIB_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sysexits.h>
#include <errno.h>

#define LEFT 0
#define RIGHT 1

typedef struct node_{
    struct node_ *D, *R, *L;
    int k;
} node;

node *makeNode(int k);
int addSon(int LorR, node *current, int k);
int deleteSon(int LorR, node *current);

int isLeaf(node *n);
int isRoot(node *n);
void printNode(node *n);

#endif //DATASTRUCT_TREELIB_H
