//
// Created by alfy on 26/11/20.
//
#include <stdio.h>
#include <stdlib.h>

#define N1 3
#define N2 4


void main (){
    long M[N1][N2];
    long *lPointer = M;
    for (int i = 0; i< N1*N2;i++){
        *(lPointer+i) = i;
    }

    for (int j = 0; j < N1; ++j) {
        printf("| ");
        for (int i = 0; i < N2; ++i) {
            printf("\t%ld",M[j][i]);
        }
        printf("\t|\n");
    }

}