//
// Created by alfy on 26/11/20.
//
#include <stdio.h>
#include <stdlib.h>

#define N1 2
#define N2 2
#define N3 3

int address3D(int n1, int n2, int n3) {
    return n3 + N3 * (n2 + N2 * (n1));
}

void main() {
    long M[N1][N2][N3];
    long *Mbase = &M[0][0][0];

    int address;
    long *celPointer;
    for (int k = 0; k < N3; ++k) {
        for (int i = 0; i < N2; ++i) {
            for (int j = 0; j < N1; ++j) {
                address = address3D(j, i, k);
                celPointer = Mbase + address;
                printf("Address = %d, Result Pointer = %p\n", address, celPointer);
                *celPointer = (long) address;
            }
        }
    }

    for (int i = 0; i < N1; ++i) {
        printf("n1=%d\n",i);
        for (int j = 0; j < N2; ++j) {
            printf("| ");
            for (int k = 0; k < N3; ++k) {
                printf("\t%ld", M[i][j][k]);
            }
            printf("\t|\n");
        }
        printf("\n");
    }
}