//
// Created by alfy on 26/11/20.
//
#include <stdio.h>
#include <stdlib.h>

#define N1 3
#define N2 4

int address2D(int n1, int n2) {
    return n2 + N2 * n1;
}

void main() {
    long M[N1][N2];
    long *Mbase = &M[0][0];

    int address;
    long *celPointer;
    for (int i = 0; i < N2; ++i) {
        for (int j = 0; j < N1; ++j) {
            address = address2D(j, i);
            celPointer = Mbase + address;
            printf("Address = %d, Result Pointer = %p\n", address, celPointer);
            *celPointer = (long) address;
        }
    }

    for (int j = 0; j < N1; ++j) {
        printf("| ");
        for (int i = 0; i < N2; ++i) {
            printf("\t%ld", M[j][i]);
        }
        printf("\t|\n");
    }

}