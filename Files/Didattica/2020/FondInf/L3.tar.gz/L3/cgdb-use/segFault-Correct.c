#include <stdio.h>


int main() {
    char *testo = "Sei pronto a divertirti?";
	printf("Ciao mondo\n");
    printf("%s\n",testo);
    return 0;
}

 
