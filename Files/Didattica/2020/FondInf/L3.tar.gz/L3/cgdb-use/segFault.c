#include <stdio.h>


int main() {
    char *testo;
	printf("Ciao mondo\n");
    printf("%s\n",testo);
    return 0;
}

 
