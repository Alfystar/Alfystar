#include <stdio.h>
#include "user_play.h"
#include "computer_play.h"
#include "winner.h"

#define NONE 3 		// nessun vincitore
#define USER 4 		// vince utente
#define COMPUTER 5 	// vince computer

int main() {
	/* il giocatore sceglie la giocata */
	int user = get_user_play();
	
	/* il computer sceglie la giocata */
	int computer = get_computer_play();

	/* controlla chi è il vincitore */
	int result = the_winner_is(user, computer);

	switch (result) {
		case USER:
			printf("Tu hai giocato %d e il computer %d: HAI VINTO!\n", user, computer);
			break;
		case COMPUTER:
			printf("Tu hai giocato %d e il computer %d: HAI PERSO!\n", user, computer);
			break;
		default: 
			printf("Tu hai giocato %d e il computer %d: PARI!\n", user, computer);
	}
}
