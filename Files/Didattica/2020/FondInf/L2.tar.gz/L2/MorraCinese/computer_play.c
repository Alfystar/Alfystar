#include <stdlib.h>
#include "computer_play.h"

int get_computer_play() {
	return rand() % 3; // e se oltre a sasso, carta e forbici ci fosse stata un'altra opzione?
}
