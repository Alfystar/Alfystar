#include "winner.h"
#include <stdio.h>

#define CARTA 0
#define SASSO 1
#define FORBICI 2 


#define NONE 3 		// nessun vincitore
#define USER 4 		// vince utente
#define COMPUTER 5 	// vince computer

int the_winner_is(int user, int computer) {
	
	switch (user) {
		case CARTA:
	 		
	 		if (computer == CARTA) 
	 			return NONE; 
	 	
	 		else if (computer == SASSO) 
	 			return USER;
	 	
		 	else if (computer == FORBICI)
		 		return COMPUTER;
	 	case SASSO:
			
			if (computer == SASSO)
				return NONE;

	 		else if (computer == CARTA)
	 			return COMPUTER;
	 		
	 		else if (computer == FORBICI ) 
	 			return USER;

	 	case FORBICI:
	 	
	 		if (computer == FORBICI ) 
	 			return NONE;
	 		
	 		else if (computer == SASSO) 
	 			return COMPUTER;

	 		else if (computer == CARTA)
	 			return USER;
	 				
	 	default:
			printf("Errore\n");
	}
}
