#include <stdio.h>
#include "user_play.h"

int get_user_play() {

	int u = -1;

	while (u<0 || u>2) {
		int value;
		printf("Inserisci 0 per giocare carta, 1 per giocare sasso, 2 per giocare forbici\n");
		scanf("%d", &value);
		u=value;
	}
	return u;
}
