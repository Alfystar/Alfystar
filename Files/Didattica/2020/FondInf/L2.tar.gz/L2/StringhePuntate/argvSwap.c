//
// Created by alfy on 16/11/20.
//
#include <stdlib.h>
#include <stdio.h>

int main (int argc, char *argv[]){

    char *appoggio = NULL;
    printf("Scan to reverse & swap\n");
    for (int i = 0; i<argc/2; i++){     // argv/2 poichè a metà lista avrò invertito tutta la lista
        appoggio = argv[argc-i-1];      // Per evitare di perdere il dato lo salvo su una variabile opportuna
        argv[argc-i-1] = argv[i];       // copio il valore corrente nel mio speculare
        argv[i] = appoggio;             // copio il valore PRECEDENTE del mio speculare
        printf("(%d)%s\n",i,argv[i]);
    }

    printf("\nPrint reverse list\n");
    for (int i = 0; i<argc; i++){
        printf("(%d)%s\n",i,argv[i]);
    }


    return 0;
}
