//
// Created by alfy on 16/11/20.
//
#include <stdlib.h>
#include <stdio.h>

void swap(int len, char **buf){         //Passo la lunghezza e il PUNTATORE al 1° elemento di ARGV
    char *appoggio = NULL;
    printf("Scan to reverse & swap\n");
    for (int i = 0; i<len/2; i++){      // argv/2 poichè a metà lista avrò invertito tutta la lista
        appoggio = *(buf+len-i-1);      // Per evitare di perdere il dato lo salvo su una variabile opportuna
        *(buf+len-i-1) = *(buf+i);      // copio il valore corrente nel mio speculare
        *(buf+i) = appoggio;            // copio il valore PRECEDENTE del mio speculare
        printf("(%d)%s\n",i,buf[i]);
    }
}

#define arraySizeOf(x) sizeof(x)/sizeof(x[0])   // macro per usare un "simil" sizeof

int main (){
    
    char *list[5];                                  // Creo nello stack un array di puntatori con 5 elementi
    // Scrivo in ogni cella dell'array un puntatore che punta ad una stringa in
    list[0] = "Prima frase";                
    list[1] = "Mentre questa è la Seconda";
    list[2] = "Ben venuto alla 3°";
    list[3] = "Come voliamo rapidi verso la 4°!";
    list[4] = "Ed eccoci alla 5°";
    
    // Lo swap come prima ma con questa lista di puntatori creata da noi
    swap(arraySizeOf(list), list);

    printf("\nPrint reverse list\n");
    for (int i = 0; i<arraySizeOf(list); i++){
        printf("(%d)%s\n",i,list[i]);
    }


    return 0;
}
