//
// Created by alfy on 16/11/20.
//
#include <stdlib.h>
#include <stdio.h>

int main (int argc, char *argv[]){

    for (int i = 0; i<argc; i++){       // Scorro tutta la lista
        printf("(%d)%s\n",i,argv[i]);   // Printo un elemento della lista
    }

    return 0;
}
