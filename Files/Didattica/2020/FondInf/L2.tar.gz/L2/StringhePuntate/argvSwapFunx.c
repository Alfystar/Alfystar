//
// Created by alfy on 16/11/20.
//
#include <stdlib.h>
#include <stdio.h>

void swap(int len, char **buf){         //Passo la lunghezza e il PUNTATORE al 1° elemento di ARGV
    char *appoggio = NULL;
    printf("Scan to reverse & swap\n");
    for (int i = 0; i<len/2; i++){      // argv/2 poichè a metà lista avrò invertito tutta la lista
        appoggio = *(buf+len-i-1);      // Per evitare di perdere il dato lo salvo su una variabile opportuna
        *(buf+len-i-1) = *(buf+i);      // copio il valore corrente nel mio speculare
        *(buf+i) = appoggio;            // copio il valore PRECEDENTE del mio speculare
        printf("(%d)%s\n",i,buf[i]);
    }
}


int main (int argc, char *argv[]){

    swap(argc, argv);           //Passo lunghezza e puntatore ad argv    
    //swap(argc, &argv[0]);     //NOTA: il puntatore ad argv = indirizzo di memoria del 1° elemento dell'array di argv

    printf("\nPrint reverse list\n");
    for (int i = 0; i<argc; i++){
        printf("(%d)%s\n",i,argv[i]);
    }


    return 0;
}
