//
// Created by alfy on 16/11/20.
//
#include <stdlib.h>
#include <stdio.h>

int main (int argc, char *argv[]){

    char *argvReverse[argc];    // Lista di appoggio per la sequenza inversa

    printf("Scan to reverse\n");
    for (int i = 0; i<argc; i++){
        argvReverse[i] = argv[argc-i-1];    // Metto nella posizione attuale, il valore del mio "speculare"
        printf("(%d)%s\n",i,argv[i]);
    }

    printf("\nPrint reverse list\n");
    for (int i = 0; i<argc; i++){
        printf("(%d)%s\n",i,argvReverse[i]);
    }


    return 0;
}
