//
// Created by alfy on 23/12/20.
//

#ifndef THEGAMEOFLIFE_FILEOP_H
#define THEGAMEOFLIFE_FILEOP_H

#include "gofLib.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>

plane *plainLoad();
void save(plane *p);

#endif //THEGAMEOFLIFE_FILEOP_H
