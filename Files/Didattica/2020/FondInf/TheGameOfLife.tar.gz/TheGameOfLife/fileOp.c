//
// Created by alfy on 23/12/20.
//

#include "fileOp.h"

int fd;


plane *plainLoad() {
    fd = open("gol.txt", O_RDONLY);
    int size = 0;
    plane *p = NULL;
    if (fd == -1) {
        switch (errno) {
            case EACCES: // file not exist
                fd = creat("gol.txt", 0666);
                printf("Select size of Plain:");
                scanf("%d", &size);
                p = makePlane(size);
                save(p);
                return p;
                break;
            default:
                perror("[fileOp.c::plainLoad] Opening of gol.txt fail");
                exit(EXIT_FAILURE);
        }
    }

    char input[4096];
    memset(input,0,4096);
    lseek(fd,SEEK_SET,0);
    int i = 0;
    do{
        read(fd,input+i,1);
        i++;
    }while (input[i-1]!='\n');
    size = atoi(input);
    p = makePlane(size);
    for (int y = 0; y < p->size; y++ ){
        read(fd,input,p->size+1);
        for(int x = 0; x< p->size;x++){
            p->table[x][y] = input[x] - '0';
        }
    }
    close(fd);
    return p;
}

void save(plane *p) {
    if(!p){
        printf("[fileOp.c::save] plain to save NULL");
        exit(EXIT_FAILURE);
    }
    fd = open("gol.txt", O_CREAT| O_TRUNC |O_RDWR, 0666);
    if (fd == -1) {
        switch (errno) {
            default:
                perror("[fileOp.c::save] Opening of gol.txt fail");
                exit(EXIT_FAILURE);
        }
    }
    char line[4096];
    int nChar = sprintf(line,"%d\n",p->size);
    write(fd,line,nChar);
    for (int y = 0; y < p->size; y++ ){
        int i = 0;
        for (int x = 0; x < p->size; x++ ){
            line[i] = p->table[x][y] + '0'; //scrivo 0 o 1
            i++;
        }
        line[i] = '\n';
        i++;
        write(fd,line,i);
    }
    close(fd);
}