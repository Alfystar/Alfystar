//
// Created by alfy on 22/12/20.
//

#include "gofLib.h"

plane *makePlane(int n) {
    plane *p = malloc(sizeof(plane));
    p->size = n;
    p->table = malloc(sizeof(char *) * n);
    for(int i = 0; i < n; i++)
    {
        p->table[i] = (char *) malloc(n * sizeof(char));
        if(p->table[i] == NULL)
        {
            fprintf(stderr, "out of memory\n");
            exit(EXIT_FAILURE);
        } else{
            memset(p->table[i], DEAD, n * sizeof(char));
        }
    }

    return p;
}

int freePlain(plane *p) {
    if (p) {
        if (p->table){
            for(int i = 0; i < p->size; i++)
                free(p->table[i]);
            free(p->table);
        }
        free(p);
        return 0;
    } else
        return -1;
}

int nearCount(plane *cP, int x, int y) {
    int near = 0;

    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            if (((x + i) >= 0 && (x + i) < cP->size) && ((y + j) >= 0 && (y + j) < cP->size)) {
                near += cP->table[x + i][y + j];
            }
        }
    }
    near -= cP->table[x][y];    // annullo la mia casella

    return near;

}

// Regole di vita e morte celle
char ruleApply(plane *cP, int x, int y) {
    int near = nearCount(cP, x, y);
    if (cP->table[x][y] == LIVE) {
        if (near >= 2 && near <= 3)
            return LIVE;
        else
            return DEAD;
    } else {
        if (near == 3)
            return LIVE;
        else
            return DEAD;
    }
}

void calcNewState(plane *oldP, plane *newP) {
    for (int x = 0; x < oldP->size; x++) {
        for (int y = 0; y < oldP->size; y++) {
            newP->table[x][y] = ruleApply(oldP, x, y);
        }
    }
}

void turnProgress(int step, plane **p) {
    plane *newP;
    for (int i = 0; i < step; ++i) {
        newP = makePlane((*p)->size);
        calcNewState(*p, newP);
        freePlain(*p);
        *p = newP;
        printTable(*p);
//        sleep(1);
    }
}

void printLine(int n) {
    printf("+");
    for (int i = 0; i < n; i++) {
        printf("-+");
    }
    printf("\n");
}

void printTable(plane *p) {
    printLine(p->size);
    for (int y = 0; y < p->size; y++) {
        for (int x = 0; x < p->size; x++) {
            if (p->table[x][y] == LIVE)
                printf("|#");
            else {
                printf("| ");
            }
        }
        printf("|\n");
    }
    printLine(p->size);
}
