//
// Created by alfy on 05/12/20.
//
#include <sysexits.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define fflush(stdin) while ((getchar()) != '\n')

#define len 64

struct dataNode{
    int count;
    char dataWrite[len];
};

int counter = 0;
struct dataNode* makeNode(char *text){
    struct dataNode* node;
    node = malloc(sizeof(struct dataNode));
    memset(node,0,sizeof(struct dataNode));
    node->count = counter;
    counter++;
    strcpy(node->dataWrite,text);
    return node;
}

void printNode(struct dataNode* node){
    printf("(%d) %s\n",node->count,node->dataWrite);

}

int main (int argc, char* argv[]){
    struct dataNode *storeNode[100];
    int i = 0;
    char input[len];
    while (strcmp(input,"q")!=0){
        printf("Inserire una frase da salvare:\n>>\t");
        scanf("%[^\n]",input);
        storeNode[i] = makeNode(input);
        i++;
    }

    for(;i>0;i--){
        printNode(storeNode[i]);
    }

    printf("Liberiamo la memoria:\n");
    for (int j = 0; j <= counter; ++j) { //Minore stretto, altrimenti si supera
        free(storeNode[j]);
    }
    printf("Free- terminata\n");

    return EX_OK;
}