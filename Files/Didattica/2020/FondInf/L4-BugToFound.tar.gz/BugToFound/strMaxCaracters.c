
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define fflush(stdin) while ((getchar()) != '\n')


void printString(char *array) {
    printf("\nStampa stringa\n>>\t%s\n", array);
}

void printStringArray(char **array, int n) {
    int i;
    unsigned int j;
    for (i = 0; i < n; i++) {
        printf("Stampa stringa in posizione %d\n>>\t", i);
        for (j = 0; j < strlen(*(array + i)); j++) {
            printf("%c", *(*(array + i) + j));
        }
        printf("\n");
    }
}

void printStringReverse(char *stringa) {
    unsigned int len;
    int i;

    len = strlen(stringa);
    i = (int) len - 1;

    while (i >= 0) {
        printf("%c", *(stringa + i));
        i--;
    }
    printf("\n");
}

void printStringArrayReverse(char **array, int n) {
    int i;
    unsigned int j;
    for (i = n - 1; i >= 0; i--) {
        printf("Stampa stringa in posizione %d\n\t", i);
        printStringReverse(*(array + i));
        printf("\n");
    }
}

char maxCharInString(char *string) {

    char max = *string;
    int i;
    for (i = 1; i < strlen(string); i++) {
        if (max < *(string + i))
            max = *(string + i);
    }
    return max;
}

char maxCharInStringArray(char **string, int n) {

    char max = **string;
    int i, j;
    for (i = 1; i < n; i++) {
        for (j = 0; j < strlen(*string); j++) {
            if (max < *(*(string + i) + j)) {
                max = *(*(string + i) + j);
            }
        }
    }
    return max;
}

char *stringa = "questa e' un altro array di stringhe\0";
int i, n;

#define DYNAMIC

int main(void) {
#ifdef DYNAMIC
    printString(stringa);
    printStringReverse(stringa);

    printf("Inserisci dimensione array di stringhe: ");
    scanf("%d", &n);
    fflush(stdin);

    // array di N puntatori a char
    char *array[n];

    for (i=0; i<n; i++) {
        printf("Inserisci stringa n. %d\n", i);
        scanf("%[^\n]", array[i]);
    }
    printStringArray(array, n);
#else
    #define N 6
    n = N;
    char *array[N] = {"questo", "e'", "un", "array", "di", "stringhe"}; // array di N puntatori a char
    printStringArrayReverse(array, n);
#endif

    printf("MAX *: %c\n", maxCharInString(stringa));
    printf("MAX **: %c\n", maxCharInStringArray(array, n));

    exit(EXIT_SUCCESS);

}
