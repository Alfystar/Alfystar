//
// Created by alfy on 22/12/20.
//

#ifndef THEGAMEOFLIFE_GOFLIB_H
#define THEGAMEOFLIFE_GOFLIB_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define DEAD 0
#define LIVE 1

typedef struct plane_{
    int size;
    char **table;
}plane;

plane *makePlane(int n);
int freePlain(plane *p);

int nearCount(plane *cP, int x, int y);
char ruleApply(plane *cP, int x, int y);
void calcNewState(plane *oldP, plane *newP);
void turnProgress(int step, plane **p);

void printTable(plane *p);


#endif //THEGAMEOFLIFE_GOFLIB_H
