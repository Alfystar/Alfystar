//
// Created by alfy on 22/12/20.
//
#include <stdlib.h>
#include <stdio.h>

#include "gofLib.h"
#include "fileOp.h"

#define fflush(stdin) while(getchar()!='\n')

#define NO_INPUT 0
#define LOAD_STATE 1
#define SHOW_STATE 2
#define STEP_STATE 3
#define MULTIPLE_STATE 4
#define SAVE_STATE 5
#define EXIT 6

plane *p;

int commandChose(){
    int command;
RETRY:
    printf("Select the option:\n");
    printf("LOAD_STATE 1\tSHOW_STATE 2\n");
    printf("STEP_STATE 3\tMULTIPLE_STATE 4\n");
    printf("SAVE_STATE 5\tEXIT 6\n");
    printf(">> ");
    scanf("%d",&command);
    fflush(stdin);
    if(command<LOAD_STATE || command>EXIT){
        printf("\nCommand unknown,\n");
        goto RETRY;
    }
    return command;
}

int exeOp(int command){
    int turns=0;
    switch (command) {
        case LOAD_STATE:
            if(p)
                freePlain(p);
            p = plainLoad();
            break;
        case SHOW_STATE:
            printTable(p);
            break;
        case STEP_STATE:
            turnProgress(1,&p);
            break;
        case MULTIPLE_STATE:
            printf("Select number of turn: ");
            scanf("%d",&turns);
            turnProgress(turns,&p);
            break;
        case SAVE_STATE:
            save(p);
            break;
        case EXIT:
            printf("Program shutdown\n");
            exit(EXIT_SUCCESS);
            break;
        default:
            printf("[main.c::exeOP] command unknown: %d\n", command);
            exit(EXIT_FAILURE);
    }
}

int main (int argc, char* argv[]){
    p=makePlane(8);
    for (int x = 0; x<8;x++)
        for (int y = 0; y<8;y++)
            p->table[x][y] = LIVE;
    while (1){
        exeOp(commandChose());
    }

}