//
// Created by alfy on 11/01/21.
//

#ifndef THEGAMEOFLIFE_AULA_GOLLIB_H
#define THEGAMEOFLIFE_AULA_GOLLIB_H

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>

#define LIVE 1
#define DEAD 0

struct plane_{
    int size;
    char **table;
};
typedef struct plane_ plane;

//#define n 8
//typedef struct char[n][n] plane;

// genera la tabella PULITA
plane *makePlane(int size);
void freePlane(plane *p);

//Funzione che ritorna i vicini VIVI
int countNear(plane *old, int x, int y);
char ruleApply(plane *old, int x, int y);

plane *calcNewStep(plane *old);
void calcKstep(plane **p, int step);

void calcNewState(plane *oldP, plane *newP);

void printTable(plane *p);


#endif //THEGAMEOFLIFE_AULA_GOLLIB_H
