//
// Created by alfy on 11/01/21.
//

#ifndef THEGAMEOFLIFE_AULA_FILEOP_H
#define THEGAMEOFLIFE_AULA_FILEOP_H

#include "golLib.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>


plane *plainLoad();
void save(plane *p);

#endif //THEGAMEOFLIFE_AULA_FILEOP_H
