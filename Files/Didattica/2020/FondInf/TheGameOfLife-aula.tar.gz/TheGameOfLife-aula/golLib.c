//
// Created by alfy on 11/01/21.
//

#include "golLib.h"

plane *makePlane(int size) {
    plane *res;
    res = malloc(sizeof(plane));

    res->size = size;
    res->table = calloc(size, sizeof(char *));

    if (!res->table) {
        perror("[golLib.c::makePlane] Error in calloc 1:");
        exit(EXIT_FAILURE);
    }
    for (int i = 0; i < size; i++) {
        res->table[i] = calloc(size, sizeof(char));
        if (!res->table[i]) {
            perror("[golLib.c::makePlane] Error in calloc 2:");
            exit(EXIT_FAILURE);
        }
        memset(res->table[i], 0, size * sizeof(char));
    }
    return res;
}


void freePlane(plane *p) {
    for (int i = 0; i < p->size; i++) {
        free(p->table[i]);
    }
    free(p->table);
    free(p);
}


int countNear(plane *old, int x, int y) {
    int countLive = 0;
    for (int i = -1; i <= 1; i++) {
        for (int k = -1; k <= 1; k++) {
            if (((x + i >= 0) && (x + i < old->size)) && ((y + k >= 0) && y + (k < old->size)))
                countLive += old->table[x + i][y + k];
        }
    }
    countLive -= old->table[x][y];
    return countLive;
}

char ruleApply(plane *old, int x, int y) {
    int near = countNear(old, x, y);
    if(old->table[x][y]==LIVE){
        if(near<2)
            return DEAD;    //isolamento
        if(near==2 || near==3)
            return LIVE;
        if(near>3)
            return DEAD;    //sovraffollamento
    }else{
        if(near==3)
            return LIVE;    //riproduzione
        else
            return DEAD;
    }
    return DEAD;
}

//plane *calcNewStep(plane *old){
//    plane *new = makePlane(old->size);
//    for(int x = 0; x<old->size;x++){
//        for(int y = 0; y<old->size;y++){
//            new->table[x][y] = ruleApply(old,x,y);
//        }
//    }
//    return new;
//}

void calcNewState(plane *oldP, plane *newP) {
    for (int x = 0; x < oldP->size; x++) {
        for (int y = 0; y < oldP->size; y++) {
            newP->table[x][y] = ruleApply(oldP, x, y);
        }
    }
}

//plane *calcKstep(plane **old, int k){
//    plane *new=*old;
//    for (int i = 0; i<k; i++){
//        new = calcNewStep(new);
//        free(*old);
//        old=&new;
//    }
//    return new;
//}

void calcKstep(plane **p, int step) {
    plane *newP;
    for (int i = 0; i < step; ++i) {
        newP = makePlane((*p)->size);
        calcNewState(*p, newP);
        freePlane(*p);
        *p = newP;
        printTable(*p);
//        sleep(1);
    }
}

void printLine(int n) {
    printf("+");
    for (int i = 0; i < n; i++) {
        printf("-+");
    }
    printf("\n");
}

void printTable(plane *p) {
    printLine(p->size);
    for (int y = 0; y < p->size; y++) {
        for (int x = 0; x < p->size; x++) {
            if (p->table[x][y] == LIVE)
                printf("|#");
            else {
                printf("| ");
            }
        }
        printf("|\n");
    }
    printLine(p->size);
}