//
// Created by alfy on 11/01/21.
//
#include <stdio.h>
#include <stdlib.h>
#include "golLib.h"
#include "fileOp.h"

#define NO_INPUT        0
#define LOAD_STATE      1
#define SHOW_STATE      2
#define STEP_STATE      3
#define MULTIPLE_STATE  4
#define SAVE_STATE      5
#define EXIT            6

#define fflush(stdin) while(getchar()!='\n')

plane *p;

int commandChose(){
    int command = 0;
    while (command<=NO_INPUT || command>EXIT){
        printf("Select the option:\n");
        printf("LOAD_STATE 1\tSHOW_STATE 2\n");
        printf("STEP_STATE 3\tMULTIPLE_STATE 4\n");
        printf("SAVE_STATE 5\tEXIT 6\n");
        printf(">>");
        scanf("%d",&command);
        fflush(stdin);
    }
    return command;
}

int commandExe(int com){
    int command;
    switch (com) {
        case LOAD_STATE:
            if(!p)
                freePlane(p);
            p = plainLoad();
            break;
        case SHOW_STATE:
            printTable(p);
            break;
        case STEP_STATE:
            calcKstep(&p,1);
            break;
        case MULTIPLE_STATE:
            printf("Set number of step >>");
            scanf("%d",&command);
            fflush(stdin);
            calcKstep(&p,command);
            break;
        case SAVE_STATE:
            save(p);
            break;
        case EXIT:
            exit(EXIT_SUCCESS);
            break;
        default:
            printf("[main.c::main]WARNING!!! Inside default");
            exit(EXIT_FAILURE);
    }
    return 0;
}

int main (){
    p = makePlane(8);
    while (1){
        int com = commandChose();
        printf("Input: %d\n",com);
        int err = commandExe(com);
    }
    return 0;
}
