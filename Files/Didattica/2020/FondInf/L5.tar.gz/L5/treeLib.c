//
// Created by alfy on 20/12/20.
//
#include "treeLib.h"

node *makeNode(int k){
    node *temp = (node *)malloc(sizeof(node));
    memset(temp,0, sizeof(node));
    temp->key=k;
    return temp;
}

void addSon(int LorR, node *current, int k){
    switch (LorR) {
        case LEFT:
            if(!current->L){
                current->L=makeNode(k);
                current->L->dad = current;
            }
            else
                printf("[deleteSon] LEFT son just exist!!!\n");
            break;
        case RIGHT:
            if(!current->R){
                current->R=makeNode(k);
                current->R->dad = current;
            }
            else
                printf("[deleteSon] RIGHT son just exist!!!\n");
            break;
        default:
            printf("[deleteSon] LorR param WRONG!!!\n");
            exit(-1);
    }
}

int isLeaf(node *n){    // true if no son
    return ((!n->L) && (!n->R));
}

int isRoot(node *n){
    return !n->dad;
}

void deleteSon(int LorR, node *current){
    switch (LorR) {
        case LEFT:
            if(!current->L)
                free(current->L);
            current->L=NULL;
            break;
        case RIGHT:
            if(!current->R)
                free(current->R);
            current->R=NULL;
            break;
        default:
            printf("[deleteSon] LorR param WRONG!!!\n");
            exit(-1);
    }
}

void printNode(node *n){
    printf("Node->k = %d\tisLeaf:%d\tisRoot:%d\n",n->key, isLeaf(n),isRoot(n));
}
