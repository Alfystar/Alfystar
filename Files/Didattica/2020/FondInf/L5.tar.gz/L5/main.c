//
// Created by alfy on 19/12/20.
//
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define LEFT 0
#define RIGHT 1
struct node_{
    int key;
    struct node_ *dad;
    struct node_ *L;
    struct node_ *R;
};
typedef struct node_ node;

node *makeNode(int k){
    node *temp = (node *)malloc(sizeof(node));
    memset(temp,0, sizeof(node));
    temp->key=k;
    return temp;
}

void addSon(int LorR, node *current, int k){
    switch (LorR) {
        case LEFT:
            if(!current->L){
                current->L=makeNode(k);
                current->L->dad = current;
            }
            else
                printf("[deleteSon] LEFT son just exist!!!\n");
            break;
        case RIGHT:
            if(!current->R){
                current->R=makeNode(k);
                current->R->dad = current;
            }
            else
                printf("[deleteSon] RIGHT son just exist!!!\n");
            break;
        default:
            printf("[deleteSon] LorR param WRONG!!!\n");
            exit(-1);
    }
}

int isLeaf(node *n){    // true if no son
    return ((!n->L) && (!n->R));
}

int isRoot(node *n){
    return !n->dad;
}

void deleteSon(int LorR, node *current){
    switch (LorR) {
        case LEFT:
            if(!current->L)
                free(current->L);
            current->L=NULL;
            break;
        case RIGHT:
            if(!current->R)
                free(current->R);
            current->R=NULL;
            break;
        default:
            printf("[deleteSon] LorR param WRONG!!!\n");
            exit(-1);
    }
}

void printNode(node *n){
    printf("Node->k = %d\tisLeaf:%d\tisRoot:%d\n",n->key, isLeaf(n),isRoot(n));
}

void dfsPrint(node *n){ // Deep firs search
    // Operation per every node
    printNode(n);


    // End recursion test
    if(isLeaf(n)){
        return;
    }

    // Recursive Zone
    if(n->R)
        dfsPrint(n->R);
    if(n->L)
        dfsPrint(n->L);
}

void bfsPrint(node *n){ // Breadth firs search
    // TODO: Da realizzare usando una coda
    // Il nodo corrente aggiunge tutti i figli in ordine
    // quindi si printa se stesso e si prende un nuovo nodo dalla pipe
    
    // Lavoro per le vacanze
}

void main (int argc, char *argv[]){

    node root={
            .key = 0,
            .dad = NULL,
            .R = NULL,
            .L = NULL
    };

    addSon(RIGHT,&root,1);
    addSon(LEFT,&root,2);
    addSon(RIGHT,root.R,3);
    addSon(LEFT,root.R,4);

    dfsPrint(&root);
}
