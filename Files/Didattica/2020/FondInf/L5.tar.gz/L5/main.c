//
// Created by alfy on 19/12/20.
//
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "treeLib.h"
#include "queueLib.h"


void dfsPrint(node *n){ // Deep firs search
    // Operation per every node
    printNode(n);


    // End recursion test
    if(isLeaf(n)){
        return;
    }

    // Recursive Zone
    if(n->R)
        dfsPrint(n->R);
    if(n->L)
        dfsPrint(n->L);
}


void bfsPrintRecursive(node *n, queue *q){ // Breadth firs search

    // Operation per every node
    printNode(n);

    // End recursion test
    if(!isLeaf(n)){
        if(n->R)
            push(q,n->R);
        if (n->L)
            push(q,n->L);
    }

    // Recursive Zone
    node *newNode = pop(q);
    bfsPrintRecursive(newNode,q);
}

void bfsPrint(node *n) { // Breadth firs search
    queue *q = initQueue();
    bfsPrintRecursive(n,q);
    deleteQueue(q);
}

void main (int argc, char *argv[]){
    node root={
            .key = 0,
            .dad = NULL,
            .R = NULL,
            .L = NULL
    };

    addSon(RIGHT,&root  ,1);
    addSon(LEFT ,&root  ,2);
    addSon(RIGHT,root.R ,3);
    addSon(LEFT ,root.R ,4);
    addSon(RIGHT,root.L ,5);
    addSon(LEFT ,root.L ,6);

    printf("dfsPrint:\n");
    dfsPrint(&root);
    printf("\n");

    printf("bfsPrint:\n");
    bfsPrint(&root);
}