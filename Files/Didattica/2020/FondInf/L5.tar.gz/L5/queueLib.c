//
// Created by alfy on 20/12/20.
//

#include "queueLib.h"

queue *initQueue(){
    queue *q = malloc(sizeof(queue));
    memset(q,0,sizeof(queue));
}



// Funzione privata
entry * makeEntry(void *d){
    entry *e = malloc(sizeof(entry));
    memset(e,0, sizeof(entry));
    e->pData=d;
    return e;
}

void push(queue *q, void *data){
    entry *e = makeEntry(data);
    if(!q->head && !q->tail){
        q->head = e;
        q->tail = e;
        e->before=e;
        e->after=e;
    } else{
        q->head->before = e;
        e->after = q->head;
        q->head = e;
    }
    q->len++;
}

// Funzione privata
void *freeEntry(entry *e){
    void *ret = NULL;
    if(e){
        ret = e->pData;
        free(e);
    }
    return ret;
}

void *pop(queue *q){
    if(q->len==0){
        printf("[pop] queue empty\n");
        return NULL;
    }
    void *e = q->tail;
    q->tail = q->tail->before;
    q->len--;
    return freeEntry(e);
}

void deleteQueue(queue *q){
    // Pulisco la memoria
    while (pop(q)!=NULL);
    free(q);
}

void queueStat(queue *q){
    printf("Queue have %d element inside\n\thead->%p\ttail->%p\n",q->len,q->head,q->tail);
}