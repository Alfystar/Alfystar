//
// Created by alfy on 20/12/20.
//

#ifndef DATASTRUCT_TREELIB_H
#define DATASTRUCT_TREELIB_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define LEFT 0
#define RIGHT 1
struct node_{
    int key;
    struct node_ *dad;
    struct node_ *L;
    struct node_ *R;
};
typedef struct node_ node;


node *makeNode(int k);

void addSon(int LorR, node *current, int k);

int isLeaf(node *n);
int isRoot(node *n);

void deleteSon(int LorR, node *current);

void printNode(node *n);

#endif //DATASTRUCT_TREELIB_H
