//
// Created by alfy on 20/12/20.
//

#ifndef DATASTRUCT_QUEUELIB_H
#define DATASTRUCT_QUEUELIB_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

struct entry_{
    void *pData;
    struct entry_ *before;
    struct entry_ *after;
};
typedef struct entry_ entry;

struct queue_{
    entry *head;
    entry *tail;
    int len;
};
typedef struct queue_ queue;

queue *initQueue();

void push(queue *q, void *data);
void *pop(queue *q);

void deleteQueue(queue *q);

void queueStat(queue *q);



#endif //DATASTRUCT_QUEUELIB_H
