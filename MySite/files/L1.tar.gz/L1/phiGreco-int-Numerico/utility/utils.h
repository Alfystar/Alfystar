//
// Created by alfy on 13/11/20.
//


#ifndef PHICALC_UTILS_H
#define PHICALC_UTILS_H

#include <stdbool.h>
#include <math.h>   // Necessita di usare -lm da gcc

bool insideRadius(double x, double y, double radius);

double f(double x,double r);


#endif //PHICALC_UTILS_H

