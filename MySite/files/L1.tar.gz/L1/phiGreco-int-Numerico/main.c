//
// Created by alfy on 13/11/20.
//

#include <stdlib.h>
#include <stdio.h>

#include <utils.h>

#define r 1.0       // Direttiva al compilatore
int nStep;

int main(int argc, char *argv[]){

    printf("Calcolo (approssimato) del Phi Greco\n");
    printf("Inserire #n step:");
    scanf("%d",&nStep);

    int allStep = nStep;      // Dovendo coprire un quadrato saranno n^2 punti
    
    printf("Verranno testati: %d punti\n", allStep);

    printf("Inizio Calcolo:\n");
    
    double fixStep = r/(nStep-1);       // Passo di incremento del calcolo dei punti
    double ySum = 0;

    int i = 0;  //Contatore di ciclo
    
    // For che scandisce tutti i punti del settore
    for(double x = 0; x <= r; x+=fixStep){
//            printf("Point:(%f) heigth:(%f)\n",x,f(x,r));
            ySum += f(x,r);
            i++;
//            if(i%10000000 == 0)
//                printf("...\n");
    }
    printf("ySum = %f\t i = %d\n", ySum,i);

    double phiAprox = ySum*4.0*fixStep;

    printf("Phi ~= %.20f\n",phiAprox);

    return 0;
}
