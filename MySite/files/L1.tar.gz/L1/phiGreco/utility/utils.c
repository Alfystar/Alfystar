//
// Created by alfy on 13/11/20.
//

#include "utils.h"

#define sq(x) pow(x,2)  // Macro: direttiva al compilatore parametrica, MOLTO potente

bool insideRadius(double x, double y, double radius){
    double dist = sqrt(sq(x) + sq(y));  // Distanza dal centro del punto
    return dist <= radius ;             // True se dentro il raggio

}
