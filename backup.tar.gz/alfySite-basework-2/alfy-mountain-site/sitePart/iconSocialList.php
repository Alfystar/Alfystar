<ul class="list-icons"">
<li>
    <a href="https://www.linkedin.com/in/emanuelealfano/" class="social-round-icon fa-icon"
       target="Linkedin">
        <i class="fa fa-linkedin"></i>
    </a>
</li>
<li>
    <a href="https://github.com/Alfystar" class="social-round-icon fa-icon" target="GitHub">
        <i class="fa fa-github"></i>
    </a>
</li>
<li>
    <a href="https://t.me/alfy_phone" class="social-round-icon fa-icon" target="Telegram">
        <i class="fa fa-telegram" aria-hidden="true"></i>
    </a>
</li>
</ul>
