<meta charset="UTF-8">
<meta content="IE=edge" http-equiv="X-UA-Compatible">
<meta content="width=device-width,initial-scale=1" name="viewport">
<meta content="description" name="description">
<meta name="google" content="notranslate"/>
<meta content="Mashup templates have been developped by Orson.io team" name="author">

<!-- Disable tap highlight on IE -->
<meta name="msapplication-tap-highlight" content="no">

<title>Ing. Alfano</title>


<link rel="apple-touch-icon" sizes="180x180" href="assets/apple-icon.png">
<link href="/favicon.ico" rel="icon">

<link href="/css/main.css" rel="stylesheet">
<link href="/css/grid.css" rel="stylesheet">
<link href="/css/blockStyle.css" rel="stylesheet">
<link href="/css/menu.css" rel="stylesheet">

<?php

?>